---
title: Example OIS Object
sidebarHeader: Reference
sidebarSubHeader: OIS
pageHeader: Reference → OIS → v2.0
path: /reference/ois/2.0/example.html
version: v2.0
outline: deep
tags:
---

<VersionWarning/>

<PageHeader/>

<SearchHighlight/>

<FlexStartTag/>

# {{$frontmatter.title}}

<<< @/reference/ois/2.0/example.json

<FlexEndTag/>
