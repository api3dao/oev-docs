---
title: Example OIS Object
sidebarHeader: Reference
sidebarSubHeader: OIS
pageHeader: Reference → OIS → v2.3
path: /reference/ois/latest/example.html
version: v2.3
outline: deep
tags:
---

<VersionWarning/>

<PageHeader/>

<SearchHighlight/>

<FlexStartTag/>

# {{$frontmatter.title}}

<<< @/reference/ois/latest/example.json

<FlexEndTag/>
