---
title: Example OIS Object
sidebarHeader: Reference
sidebarSubHeader: OIS
pageHeader: Reference → OIS → v2.1
path: /reference/ois/2.1/example.html
version: v2.1
outline: deep
tags:
---

<VersionWarning/>

<PageHeader/>

<SearchHighlight/>

<FlexStartTag/>

# {{$frontmatter.title}}

<<< @/reference/ois/2.1/example.json

<FlexEndTag/>
