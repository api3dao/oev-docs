---
title: Example OIS Object
sidebarHeader: Reference
sidebarSubHeader: OIS
pageHeader: Reference → OIS → v2.4
path: /reference/ois/next/example.html
version: v2.4
outline: deep
tags:
---

<VersionWarning/>

<PageHeader/>

<SearchHighlight/>

<FlexStartTag/>

# {{$frontmatter.title}}

<<< @/reference/ois/next/example.json

<FlexEndTag/>
