---
title: Example OIS Object
sidebarHeader: Reference
sidebarSubHeader: OIS
pageHeader: Reference → OIS → v2.2
path: /reference/ois/2.2/example.html
version: v2.2
outline: deep
tags:
---

<VersionWarning/>

<PageHeader/>

<SearchHighlight/>

<FlexStartTag/>

# {{$frontmatter.title}}

<<< @/reference/ois/2.2/example.json

<FlexEndTag/>
