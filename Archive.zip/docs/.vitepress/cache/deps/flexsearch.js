import "./chunk-TXPGJST7.js";

// node_modules/flexsearch/dist/module/config.js
var DEBUG = false;
var SUPPORT_ENCODER = true;
var SUPPORT_CACHE = true;
var SUPPORT_ASYNC = true;
var SUPPORT_SUGGESTION = true;
var SUPPORT_SERIALIZE = true;

// node_modules/flexsearch/dist/module/type.js
function IndexInterface() {
  this.cache = null, this.matcher = null, this.stemmer = null, this.filter = null;
}
IndexInterface.prototype.add, IndexInterface.prototype.append, IndexInterface.prototype.search, IndexInterface.prototype.update, IndexInterface.prototype.remove;

// node_modules/flexsearch/dist/module/common.js
function parse_option(a, b) {
  return "undefined" == typeof a ? b : a;
}
function create_object_array(a) {
  const b = Array(a);
  for (let c = 0; c < a; c++)
    b[c] = create_object();
  return b;
}
function get_keys(a) {
  return Object.keys(a);
}
function create_object() {
  return /* @__PURE__ */ Object.create(null);
}
function concat(a) {
  return [].concat.apply([], a);
}
function sort_by_length_down(c, a) {
  return a.length - c.length;
}
function is_array(a) {
  return a.constructor === Array;
}
function is_string(a) {
  return "string" == typeof a;
}
function is_object(a) {
  return "object" == typeof a;
}
function is_function(a) {
  return "function" == typeof a;
}

// node_modules/flexsearch/dist/module/lang.js
function pipeline(a, b, c, d) {
  if (a && (b && (a = replace(a, b)), this.matcher && (a = replace(a, this.matcher)), this.stemmer && 1 < a.length && (a = replace(a, this.stemmer)), d && 1 < a.length && (a = collapse(a)), c || "" === c)) {
    const b2 = a.split(c);
    return this.filter ? filter(b2, this.filter) : b2;
  }
  return a;
}
var regex_whitespace = /[\p{Z}\p{S}\p{P}\p{C}]+/u;
function init_filter(a) {
  const b = create_object();
  for (let c = 0, d = a.length; c < d; c++)
    b[a[c]] = 1;
  return b;
}
function init_stemmer_or_matcher(a, b) {
  const c = get_keys(a), d = c.length, e = [];
  let f = "", g = 0;
  for (let h, j, k = 0; k < d; k++)
    h = c[k], j = a[h], j ? (e[g++] = regex(b ? "(?!\\b)" + h + "(\\b|_)" : h), e[g++] = j) : f += (f ? "|" : "") + h;
  return f && (e[g++] = regex(b ? "(?!\\b)(" + f + ")(\\b|_)" : "(" + f + ")"), e[g] = ""), e;
}
function replace(a, b) {
  for (let c = 0, d = b.length; c < d && (a = a.replace(b[c], b[c + 1]), !!a); c += 2)
    ;
  return a;
}
function regex(a) {
  return new RegExp(a, "g");
}
function collapse(a) {
  let b = "", c = "";
  for (let d, e = 0, f = a.length; e < f; e++)
    (d = a[e]) !== c && (b += c = d);
  return b;
}
function filter(a, b) {
  const c = a.length, d = [];
  for (let e = 0, f = 0; e < c; e++) {
    const c2 = a[e];
    c2 && !b[c2] && (d[f++] = c2);
  }
  return d;
}

// node_modules/flexsearch/dist/module/lang/latin/default.js
function encode(a) {
  return pipeline.call(this, ("" + a).toLowerCase(), false, regex_whitespace, false);
}

// node_modules/flexsearch/dist/module/global.js
var global_lang = {};
var global_charset = {};

// node_modules/flexsearch/dist/module/async.js
function async_default(a) {
  register(a, "add"), register(a, "append"), register(a, "search"), register(a, "update"), register(a, "remove");
}
function register(a, b) {
  a[b + "Async"] = function() {
    const a2 = this, c = arguments, d = c[c.length - 1];
    let e;
    is_function(d) && (e = d, delete c[c.length - 1]);
    const f = new Promise(function(d2) {
      setTimeout(function() {
        a2.async = true;
        const e2 = a2[b].apply(a2, c);
        a2.async = false, d2(e2);
      });
    });
    return e ? (f.then(e), this) : f;
  };
}

// node_modules/flexsearch/dist/module/intersect.js
function intersect(a, b, c, d) {
  const e = a.length;
  let f, g, h = [], i = 0;
  d && (d = []);
  for (let j = e - 1; 0 <= j; j--) {
    const k = a[j], l = k.length, m = create_object();
    let n = !f;
    for (let a2 = 0; a2 < l; a2++) {
      const l2 = k[a2], o = l2.length;
      if (o)
        for (let a3, k2, p = 0; p < o; p++)
          if (k2 = l2[p], f) {
            if (f[k2]) {
              if (!j) {
                if (c)
                  c--;
                else if (h[i++] = k2, i === b)
                  return h;
              }
              (j || d) && (m[k2] = 1), n = true;
            }
            if (d && (a3 = (g[k2] || 0) + 1, g[k2] = a3, a3 < e)) {
              const b2 = d[a3 - 2] || (d[a3 - 2] = []);
              b2[b2.length] = k2;
            }
          } else
            m[k2] = 1;
    }
    if (d)
      f || (g = m);
    else if (!n)
      return [];
    f = m;
  }
  if (d)
    for (let a2, e2, g2 = d.length - 1; 0 <= g2; g2--) {
      a2 = d[g2], e2 = a2.length;
      for (let d2, g3 = 0; g3 < e2; g3++)
        if (d2 = a2[g3], !f[d2]) {
          if (c)
            c--;
          else if (h[i++] = d2, i === b)
            return h;
          f[d2] = 1;
        }
    }
  return h;
}

// node_modules/flexsearch/dist/module/cache.js
function CacheClass(a) {
  this.limit = true !== a && a, this.cache = create_object(), this.queue = [];
}
var cache_default = CacheClass;
function searchCache(a, b, c) {
  is_object(a) && (a = a.query);
  let d = this.cache.get(a);
  return d || (d = this.search(a, b, c), this.cache.set(a, d)), d;
}
CacheClass.prototype.set = function(a, b) {
  if (!this.cache[a]) {
    let b2 = this.queue.length;
    b2 === this.limit ? delete this.cache[this.queue[b2 - 1]] : b2++;
    for (let a2 = b2 - 1; 0 < a2; a2--)
      this.queue[a2] = this.queue[a2 - 1];
    this.queue[0] = a;
  }
  this.cache[a] = b;
}, CacheClass.prototype.get = function(a) {
  const b = this.cache[a];
  if (this.limit && b) {
    const b2 = this.queue.indexOf(a);
    if (b2) {
      const a2 = this.queue[b2 - 1];
      this.queue[b2 - 1] = this.queue[b2], this.queue[b2] = a2;
    }
  }
  return b;
}, CacheClass.prototype.del = function(a) {
  for (let b, c, d = 0; d < this.queue.length; d++)
    c = this.queue[d], b = this.cache[c], b.includes(a) && (this.queue.splice(d--, 1), delete this.cache[c]);
};

// node_modules/flexsearch/dist/module/preset.js
var preset = { memory: { charset: "latin:extra", resolution: 3, minlength: 4, fastupdate: false }, performance: { resolution: 3, minlength: 3, optimize: false, context: { depth: 2, resolution: 1 } }, match: { charset: "latin:extra", tokenize: "reverse" }, score: { charset: "latin:advanced", resolution: 20, minlength: 3, context: { depth: 3, resolution: 9 } }, default: {} };
function apply_preset(a) {
  if (is_string(a))
    DEBUG && !preset[a] && console.warn("Preset not found: " + a), a = preset[a];
  else {
    const b = a.preset;
    b && (DEBUG && !b[b] && console.warn("Preset not found: " + b), a = Object.assign({}, b[b], a));
  }
  return a;
}

// node_modules/flexsearch/dist/module/serialize.js
function async(a, b, c, d, e, f, g) {
  setTimeout(function() {
    const h = a(c ? c + "." + d : d, JSON.stringify(g));
    h && h.then ? h.then(function() {
      b.export(a, b, c, e, f + 1);
    }) : b.export(a, b, c, e, f + 1);
  });
}
function exportIndex(a, b, c, d, e) {
  let f, g;
  switch (e || (e = 0)) {
    case 0:
      if (f = "reg", this.fastupdate)
        for (let a2 in g = create_object(), this.register)
          g[a2] = 1;
      else
        g = this.register;
      break;
    case 1:
      f = "cfg", g = { doc: 0, opt: this.optimize ? 1 : 0 };
      break;
    case 2:
      f = "map", g = this.map;
      break;
    case 3:
      f = "ctx", g = this.ctx;
      break;
    default:
      return;
  }
  return async(a, b || this, c, f, d, e, g), true;
}
function importIndex(a, b) {
  b && (is_string(b) && (b = JSON.parse(b)), "cfg" === a ? this.optimize = !!b.opt : "reg" === a ? (this.fastupdate = false, this.register = b) : "map" === a ? this.map = b : "ctx" === a ? this.ctx = b : void 0);
}

// node_modules/flexsearch/dist/module/index.js
function Index(a, b) {
  if (!(this instanceof Index))
    return new Index(a);
  let c, d, e;
  a ? (SUPPORT_ENCODER && (a = apply_preset(a)), c = a.charset, d = a.lang, is_string(c) && (-1 === c.indexOf(":") && (c += ":default"), c = global_charset[c]), is_string(d) && (d = global_lang[d])) : a = {};
  let f, g, h = a.context || {};
  this.encode = a.encode || c && c.encode || encode, this.register = b || create_object(), this.resolution = f = a.resolution || 9, this.tokenize = e = c && c.tokenize || a.tokenize || "strict", this.depth = "strict" === e && h.depth, this.bidirectional = parse_option(h.bidirectional, true), this.optimize = g = parse_option(a.optimize, true), this.fastupdate = parse_option(a.fastupdate, true), this.minlength = a.minlength || 1, this.boost = a.boost, this.map = g ? create_object_array(f) : create_object(), this.resolution_ctx = f = h.resolution || 1, this.ctx = g ? create_object_array(f) : create_object(), this.rtl = c && c.rtl || a.rtl, this.matcher = (e = a.matcher || d && d.matcher) && init_stemmer_or_matcher(e, false), this.stemmer = (e = a.stemmer || d && d.stemmer) && init_stemmer_or_matcher(e, true), this.filter = (e = a.filter || d && d.filter) && init_filter(e), SUPPORT_CACHE && (this.cache = (e = a.cache) && new cache_default(e));
}
var module_default = Index;
Index.prototype.append = function(a, b) {
  return this.add(a, b, true);
}, Index.prototype.add = function(a, b, c, d) {
  if (b && (a || 0 === a)) {
    if (!d && !c && this.register[a])
      return this.update(a, b);
    b = this.encode("" + b);
    const e = b.length;
    if (e) {
      const d2 = create_object(), f = create_object(), g = this.depth, h = this.resolution;
      for (let j = 0; j < e; j++) {
        let i = b[this.rtl ? e - 1 - j : j], k = i.length;
        if (i && k >= this.minlength && (g || !f[i])) {
          let l = get_score(h, e, j), m = "";
          switch (this.tokenize) {
            case "full":
              if (2 < k) {
                for (let b2 = 0; b2 < k; b2++)
                  for (let d3 = k; d3 > b2; d3--)
                    if (d3 - b2 >= this.minlength) {
                      const g2 = get_score(h, e, j, k, b2);
                      m = i.substring(b2, d3), this.push_index(f, m, g2, a, c);
                    }
                break;
              }
            case "reverse":
              if (1 < k) {
                for (let b2 = k - 1; 0 < b2; b2--)
                  if (m = i[b2] + m, m.length >= this.minlength) {
                    const d3 = get_score(h, e, j, k, b2);
                    this.push_index(f, m, d3, a, c);
                  }
                m = "";
              }
            case "forward":
              if (1 < k) {
                for (let b2 = 0; b2 < k; b2++)
                  m += i[b2], m.length >= this.minlength && this.push_index(f, m, l, a, c);
                break;
              }
            default:
              if (this.boost && (l = Math.min(0 | l / this.boost(b, i, j), h - 1)), this.push_index(f, i, l, a, c), g && 1 < e && j < e - 1) {
                const f2 = create_object(), h2 = this.resolution_ctx, k2 = i, l2 = Math.min(g + 1, e - j);
                f2[k2] = 1;
                for (let g2 = 1; g2 < l2; g2++)
                  if (i = b[this.rtl ? e - 1 - j - g2 : j + g2], i && i.length >= this.minlength && !f2[i]) {
                    f2[i] = 1;
                    const b2 = get_score(h2 + (e / 2 > h2 ? 0 : 1), e, j, l2 - 1, g2 - 1), m2 = this.bidirectional && i > k2;
                    this.push_index(d2, m2 ? k2 : i, b2, a, c, m2 ? i : k2);
                  }
              }
          }
        }
      }
      this.fastupdate || (this.register[a] = 1);
    }
  }
  return this;
};
function get_score(a, b, c, d, e) {
  return c && 1 < a ? b + (d || 0) <= a ? c + (e || 0) : 0 | (a - 1) / (b + (d || 0)) * (c + (e || 0)) + 1 : 0;
}
Index.prototype.push_index = function(a, b, c, d, e, f) {
  let g = f ? this.ctx : this.map;
  if ((!a[b] || f && !a[b][f]) && (this.optimize && (g = g[c]), f ? (a = a[b] || (a[b] = create_object()), a[f] = 1, g = g[f] || (g[f] = create_object())) : a[b] = 1, g = g[b] || (g[b] = []), this.optimize || (g = g[c] || (g[c] = [])), (!e || !g.includes(d)) && (g[g.length] = d, this.fastupdate))) {
    const a2 = this.register[d] || (this.register[d] = []);
    a2[a2.length] = g;
  }
}, Index.prototype.search = function(a, b, c) {
  c || (!b && is_object(a) ? (c = a, a = c.query) : is_object(b) && (c = b));
  let d, e, f, g = [], h = 0;
  if (c && (a = c.query || a, b = c.limit, h = c.offset || 0, e = c.context, f = SUPPORT_SUGGESTION && c.suggest), a && (a = this.encode("" + a), d = a.length, 1 < d)) {
    const b2 = create_object(), c2 = [];
    for (let e2, h2 = 0, i2 = 0; h2 < d; h2++)
      if (e2 = a[h2], e2 && e2.length >= this.minlength && !b2[e2]) {
        if (!this.optimize && !f && !this.map[e2])
          return g;
        c2[i2++] = e2, b2[e2] = 1;
      }
    a = c2, d = a.length;
  }
  if (!d)
    return g;
  b || (b = 100);
  let i, j = this.depth && 1 < d && false !== e, k = 0;
  j ? (i = a[0], k = 1) : 1 < d && a.sort(sort_by_length_down);
  for (let e2, l; k < d; k++) {
    if (l = a[k], j ? (e2 = this.add_result(g, f, b, h, 2 === d, l, i), (!f || false !== e2 || !g.length) && (i = l)) : e2 = this.add_result(g, f, b, h, 1 === d, l), e2)
      return e2;
    if (f && k == d - 1) {
      let a2 = g.length;
      if (!a2) {
        if (j) {
          j = 0, k = -1;
          continue;
        }
        return g;
      }
      if (1 === a2)
        return single_result(g[0], b, h);
    }
  }
  return intersect(g, b, h, f);
}, Index.prototype.add_result = function(a, b, c, d, e, f, g) {
  let h = [], i = g ? this.ctx : this.map;
  if (this.optimize || (i = get_array(i, f, g, this.bidirectional)), i) {
    let b2 = 0;
    const j = Math.min(i.length, g ? this.resolution_ctx : this.resolution);
    for (let a2, k, l = 0, m = 0; l < j && (a2 = i[l], !(a2 && (this.optimize && (a2 = get_array(a2, f, g, this.bidirectional)), d && a2 && e && (k = a2.length, k <= d ? (d -= k, a2 = null) : (a2 = a2.slice(d), d = 0)), a2 && (h[b2++] = a2, e && (m += a2.length, m >= c))))); l++)
      ;
    if (b2)
      return e ? single_result(h, c, 0) : void (a[a.length] = h);
  }
  return !b && h;
};
function single_result(a, b, c) {
  return a = 1 === a.length ? a[0] : concat(a), c || a.length > b ? a.slice(c, c + b) : a;
}
function get_array(a, b, c, d) {
  if (c) {
    const e = d && b > c;
    a = a[e ? b : c], a = a && a[e ? c : b];
  } else
    a = a[b];
  return a;
}
Index.prototype.contain = function(a) {
  return !!this.register[a];
}, Index.prototype.update = function(a, b) {
  return this.remove(a).add(a, b);
}, Index.prototype.remove = function(a, b) {
  const c = this.register[a];
  if (c) {
    if (this.fastupdate)
      for (let b2, d = 0; d < c.length; d++)
        b2 = c[d], b2.splice(b2.indexOf(a), 1);
    else
      remove_index(this.map, a, this.resolution, this.optimize), this.depth && remove_index(this.ctx, a, this.resolution_ctx, this.optimize);
    b || delete this.register[a], SUPPORT_CACHE && this.cache && this.cache.del(a);
  }
  return this;
};
function remove_index(a, b, c, d, e) {
  let f = 0;
  if (!is_array(a))
    for (let g in a)
      f = remove_index(a[g], b, c, d, e), f || delete a[g];
  else if (!e) {
    e = Math.min(a.length, c);
    for (let g, h = 0; h < e; h++)
      g = a[h], g && (f = remove_index(g, b, c, d, e), !d && !f && delete a[h]);
  } else {
    const c2 = a.indexOf(b);
    -1 === c2 ? f++ : 1 < a.length && (a.splice(c2, 1), f++);
  }
  return f;
}
SUPPORT_CACHE && (Index.prototype.searchCache = searchCache), SUPPORT_SERIALIZE && (Index.prototype.export = exportIndex, Index.prototype.import = importIndex), SUPPORT_ASYNC && async_default(Index.prototype);
export {
  module_default as default
};
//# sourceMappingURL=flexsearch.js.map
