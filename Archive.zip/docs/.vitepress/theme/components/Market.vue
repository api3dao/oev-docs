<template>
  <div>
    <a href="https://market.api3.org" target="_blank"
      ><button
        style="
          margin-top: 20px;
          background: black;
          border: 1px solid gray;
          border-radius: 0.3em;
          font-size: x-large;

          padding: 9px 10px 4px 10px;
          cursor: pointer;
        "
      >
        <img
          src="/img/api3-inactive.png"
          style="float: left; margin-top: -5px; width: 40px"
        />
        <span style="color: white">API3 MARKET </span>
      </button></a
    >
  </div>
</template>

<script>
export default {
  name: 'Market',
};
</script>
