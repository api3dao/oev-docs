<template>
  <div>
    <a href="https://old-docs.api3.org" target="_blank"
      ><button
        style="
          margin-top: 20px;
          background: lightslategrey;
          border-radius: 0.3em;
          border: 2px solid gray;
          color: white;
          font-size: small;
          padding: 4px 10px 4px 10px;
          max-width: 250px;
          cursor: pointer;
        "
      >
        View the legacy documentation
      </button></a
    >
  </div>
</template>

<script>
export default {
  name: 'LegacyDocs',
};
</script>
