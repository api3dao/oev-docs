---
title: Google Analytics
sidebarHeader: Docs Development
sidebarSubHeader:
pageHeader: Docs Development
path: /dev/ga4.html
outline: deep
tags:
---

<PageHeader/>

# {{$frontmatter.title}}

::: danger Work in progress

Not worth reading at this point. Still working on it.

:::

`https://www.google.com/search?client=safari&rls=en&q=tutorial+google+analyticts+4&ie=UTF-8&oe=UTF-8#fpstate=ive&vld=cid:dd7bbe7d,vid:iJyGEuiIjOk`

https://github.com/vuejs/vitepress/issues/1131
