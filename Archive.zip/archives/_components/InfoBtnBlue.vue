<template>
  <img :src="withBase('/img/info-blue-20.png')" alt="info" class="infoIcon" />
</template>

<script setup>
import { withBase } from 'vitepress';
</script>
