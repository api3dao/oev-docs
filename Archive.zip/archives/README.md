The archive folder holds files that may need to be added back into the docs in
the future.

The reason they are stored here is to prevent the FlexSearch build task from
indexing them as every file in `/docs` is normally indexed.

See `/dev/flexsearch.html`.
